This is an enhanced Default Template for pnp4nagios and IcingaWeb2 that completely replaces the rather basic default template that comes with pnp4nagios. This template was made because because I was fed up from insane measurement units such as 10mGB or 10Mms, the unappealing, oldfashioned and inconsistent graph colors and the amount of time it took to apply and manage changes across numerous templates in order to keep them consistent. While it seems impossible to solve all rrdgraphe issues completely, it is believed to be an improvement and should work sufficiently with most Nagios Check Commands out of the box.

Features:

    Modern looking graphs that matches the Icingaweb2 color scheme
    Global graph attributes can be very easily changed
    Avoids display of weird Units such as 2222.5mGB or 0.10kms (well, at least mostly)
    Makes all graps show consistent measurement units so that througput is always shown in GB/s for example, no matter if scripts exports RRD data in KB/s, B/s or any other UOM
    Allow graphs to be shown in such a way, that it is immediately apparent from the overwiew window if something is wrong or not (hostalive4 for example)
    Correct or add UOMs (Units of measurement, such as MB) for checks with broken or missing UOM in performance data
    Change the name of unclear graph data to something more comprehensible, possibly in your native language
    Change behaviour of specific graphs without the need to create and manage multiple templates
    All changes for specific graphs are easily managed in one place (this file)
    Modifications may be done based either on the Icinga2 Service Name or on the Check Command Name. In contrast, the pnpnagios
    template system allows to use only the Check Command Name
    Easily reorder graphs, so that the most important graph is shown first and displayed in the Icingaweb2 overview page
    Easily suppress graphs that need not be shown
    Allows to add comments to a graph
    Combine multiple data points into graphs, freely override graph style (line / area / gradient) and color

Version History:

V.1.0		Initial release
V.1.0.1	Bugfix Release that makes it work with Icinga Web V.2.8.0 and PHP 7.4
V.1.2		Several improvements
V.1.2.1	Bugfixes for Icinga 2.11 and Debian 10, make graph width equal for Graphs with and without Y-axis units